import pygame
import random

class ufo(pygame.sprite.Sprite):

	# Set speed vector
	change_y = 0
	change_x = 0
	fuel_change = 0 

	def __init__(self,x,y):
		""" Constructor function """

        # Call the parent's constructor
		super().__init__()
		
		self.image = pygame.image.load("ufo.png")
		self.fuel = 500
		self.score = 0
		self.rect = self.image.get_rect()
		self.rect.y = y
		self.rect.x = x
		self.dead = False
		
	def move(self):
		""" Find a new position for the player """
        # Move up/down
		self.rect.x += self.change_x
		self.rect.y += self.change_y
		self.fuel += self.fuel_change
		if player.rect.y < 0:
			player.rect.y = 0
		if player.rect.y > 270:
			player.rect.y = 270		

class bullet(pygame.sprite.Sprite):
	
	change_y = -8
	change_x = 0		
	
	def __init__(self,x,y):
		""" Constructor function """

        # Call the parent's constructor
		super().__init__()
		self.image = pygame.Surface([1, 10])
		self.image.fill(BLANC)
		self.rect = self.image.get_rect()
		self.rect.y = y
		self.rect.x = x
	
	def move(self):
		# Move the rectangle starting point
		self.rect.y += self.change_y
		self.rect.x += self.change_x

			
class astero(pygame.sprite.Sprite):
	# Set speed vector
	change_y = 3
	change_x = 3 

	def __init__(self,x,y):
		""" Constructor function """

        # Call the parent's constructor
		super().__init__()
		
		self.image = pygame.image.load("astero.png")
		self.rect = self.image.get_rect()
		self.rect.y = y
		self.rect.x = x
	
	def move(self):
		# Move the rectangle starting point
		self.rect.x += self.change_x
		self.rect.y += self.change_y
		# Bounce the astero if needed
		if self.rect.y > 320 or self.rect.y < 0:
			self.change_y = self.change_y * -1
		# Replace astero if out
		if self.rect.x > 645 or self.rect.x < 0:
			self.change_x = self.change_x * -1 #Bounced

class orion(pygame.sprite.Sprite):
	# Set speed vector
	change_y = 7
	change_x = 7 

	def __init__(self,x,y):
		""" Constructor function """

        # Call the parent's constructor
		super().__init__()
		
		self.image = pygame.image.load("Orion.png")
		self.rect = self.image.get_rect()
		self.rect.y = y
		self.rect.x = x
		self.dead = False
	
	def move(self):
		# Move the rectangle starting point
		self.rect.x += self.change_x
		self.rect.y += self.change_y
		# Bounce the ball if needed
		if self.rect.y > 320 or self.rect.y < 0:
			self.change_y = self.change_y * -1
		# Replace the ball if out
		if self.rect.x > 645 or self.rect.x < 0:
			self.change_x = self.change_x * -1 #Bounced

def checkCollision(sprite1, sprite2):
	col = pygame.sprite.collide_rect(sprite1, sprite2)
	return col

#----------------- Définition Couleurs ---------------------------------
NOIR = (0, 0, 0)
BLANC = (255, 255, 255)
BLEU = (0, 0, 255)
ROUGE = (255, 0, 0)
VERT = (0, 255, 0)

#------------------ Défition la Surface --------------------------------			
Largeur, Hauteur = 700, 328
MiL, MiH = Largeur / 2, Hauteur / 2
AIRE = Largeur * Hauteur

#--------------------------- Initialisation ----------------------------
pygame.init()
GameOver = False
CLOCK = pygame.time.Clock()
Ecran = pygame.display.set_mode((Largeur, Hauteur))
pygame.display.set_caption("Mars Defender")

FPS = 120 
player = ufo(200,270)
enemi = orion(375,10)
missile = bullet(500,500)

movingsprites = pygame.sprite.Group()
movingsprites.add(player)
movingsprites.add(enemi)
list_astero = pygame.sprite.Group()
list_missile = pygame.sprite.Group()

for i in range(3):
	r = random.randint(10,600)
	R = random.randint(10,300)
	ast = astero(r,R)
	list_astero.add(ast)
	movingsprites.add(list_astero)

myfont1 = pygame.font.SysFont("none",20)
myfont2 = pygame.font.SysFont("none",60)

#------------------------------- Son ----------------------------------
son1 = pygame.mixer.Sound("missile.wav")
son2 = pygame.mixer.Sound("explosion.wav")
son3 = pygame.mixer.Sound("astero.wav")

#---------------------- Boucle Principale -----------------------------
while not GameOver:
	for event in pygame.event.get(): # User did something
		if event.type == pygame.QUIT: # click fermeture
			GameOver = True # Sortie de boucle
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_UP:
				if player.fuel > 0:
					player.change_y = -3
					player.fuel_change = -2
			if event.key == pygame.K_RIGHT:
				player.change_x = 3	
			if event.key == pygame.K_LEFT:
				player.change_x = -3
			if event.key == pygame.K_SPACE:
				# Fire a bullet
				missile = bullet(player.rect.x+25,player.rect.y)
				list_missile.add(missile)
				movingsprites.add(list_missile)
				son1.play()
					
		if event.type == pygame.KEYUP:
			if event.key == pygame.K_UP:
				player.change_y = 3
				player.fuel_change = 0
			if event.key == pygame.K_RIGHT:
				player.change_x = 0	
			if event.key == pygame.K_LEFT:
				player.change_x = 0		

#---------------------------- Move -------------------------------------
	for ast in list_astero:
		ast.move()
	
	for missile in list_missile:
		missile.move()
		
	player.move()	
	if player.fuel <= 0:
		player.change_y = 3	
		
	enemi.move()
	
#---------------------------- Logic ------------------------------------		
	
	for ast in list_astero:
		boum = checkCollision(player,ast) 
		if boum == True:
			player.fuel = player.fuel + 100
			ast.remove(movingsprites)
			ast.kill()
			player.score += 1
			son3.play()
		
	for missile in list_missile:
		boum2 = checkCollision(missile,enemi) 
		if boum2 == True:
			enemi.remove(movingsprites)
			player.score += 1
			enemi.kill()
			enemi.dead = True
			son2.play()
			
	boum3 = checkCollision(player,enemi)
	if boum3 == True:
		player.remove(movingsprites)
		player.kill()	
		player.dead = True
			
	if enemi.dead == True:
		r2 = random.randint(10,600)
		R2 = random.randint(10,300)
		enemi = orion(r2,R2)
		movingsprites.add(enemi)
	
	while player.dead == True or player.fuel <= 0 :
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()
	#		if event.type == pygame.KEYDOWN:
	#			if event.key == pygame.K_RETURN:
	#				player.score = 0
	#				player.dead = False
				
		label5 = myfont2.render("Game Over", 1,BLANC)
		Ecran.blit(label5, (250, 100))	
	#	CLOCK.tick(FPS)
		pygame.display.update()
		
#------------------------------ Affichage ------------------------------	
	
	bkgd = pygame.image.load("Mars.png").convert()
	Altitude = player.rect.y + (270 * -1)
	label1 = myfont1.render("Altitude : " + str(Altitude*-1) + " m", 1,BLANC)
#	label2 = myfont1.render("Contact: " + str(Altitude) + " m", 1,BLANC)
	label3 = myfont1.render("Fuel : " + str(player.fuel), 1,BLANC)
	label4 = myfont1.render("Score : " + str(player.score), 1,BLANC)
	
	Ecran.blit(bkgd,(0,0))
	movingsprites.draw(Ecran)
	Ecran.blit(label1, (580, 10))
#	Ecran.blit(label2, (580, 30))
	Ecran.blit(label3, (580, 30))
	Ecran.blit(label4, (580, 50))
	
	CLOCK.tick(FPS)
	pygame.display.update()
	

pygame.quit()
